// CODE FOR A BUBBLE OBJECT

// Bubble Class - Factory or Blueprint to build Bubble Objects
class Bubble {
	// Properties (State)
	constructor(x, y, r, col) {
		// Runs once when a Bubble object is created
		this.x = x;
		this.y = y;
		this.r = r;
		this.xSpeed = 5;
		this.ySpeed = 2;
		this.col = col;
	}

	// Methods (Behaviour)
	move() {
		// Bounce Balls
		this.y += this.ySpeed;
            this.x += this.xSpeed;
            if (this.x > width - this.r || this.x < this.r) {
                this.xSpeed = -this.xSpeed;
            }
            if (this.y > height - this.r || this.y < this.r) {
                this.ySpeed = -this.ySpeed;
            }
	}

	show() {
		// Draw Bubble
		fill(this.col);
		stroke(this.col);
		strokeWeight(3);
		ellipse(this.x, this.y, 2 * this.r);
	}

	
}
