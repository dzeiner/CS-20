// JUMPING PLAYER CLASS
class JumpingPlayer {
	// Properties (State)
	constructor(x, y, col, lk, rk, uk, dk) {
		this.x = x;
		this.y = y;
		this.r = 20;
		this.xSpeed = 5;
		this.ySpeed = 5;
		this.col = col;
		this.leftKey = lk;
		this.rightKey = rk;
		this.upKey = uk;
		this.downKey = dk;
	}

	// Methods (Behaviour)
	move() {
		// Move Horizontally on Key is Down
		if (keyIsDown(this.leftKey) && this.x > 10 ) {
			this.x += -this.xSpeed;
		} else if (keyIsDown(this.rightKey) && this.x < 790) {
			this.x += this.xSpeed;
		} else if (keyIsDown(this.upKey) && this.y > 10) {
			this.y += -this.ySpeed
		} else if (keyIsDown(this.downKey) && this.y < 590) {
			this.y += this.ySpeed
		}

	}

	show() {
		// Draw Player
		noStroke();
		fill(this.col);
		ellipse(this.x, this.y, this.r);
		if (hit == true || hit2 == true) {
			game.hidePlayer();
		}
	}
}
