class Game {
    // Properties
    constructor() {
        this.player1 = new JumpingPlayer(200, 300, 0, 65, 68, 87, 83);
        this.player2 = new JumpingPlayer(600, 300, 255, 37, 39, 38, 40);
        this.bubble1 = new Bubble(200, 400, 30, RED);
        this.bubble2 = new Bubble(500, 100, 20, BLUE);
        this.bubble3 = new Bubble(300, 500, 10, BROWN);
        this.bubble4 = new Bubble(100, 200, 25, GREY);
    }

    // Methods

    moveObjects() {
        this.player1.move();
        this.player2.move();

        this.bubble1.move();
        this.bubble2.move();
        this.bubble3.move();
        this.bubble4.move();
    }

    drawObjects() {
        this.player1.show();
        this.player2.show();
    
        this.bubble1.show();
        this.bubble2.show();
        this.bubble3.show();
        this.bubble4.show();        
    }

    objectCollision() {
        this.ballCollision(this.player1);
        this.ballCollision(this.player2);
    }

    ballCollision(aPlayer) {
        if (circleIntersect(this.bubble1, aPlayer)) {
            if (aPlayer == this.player1) {
                hit = true;
            } else if (aPlayer == this.player2) {
                hit2 = true;
            }
        } else if (circleIntersect(this.bubble2, aPlayer)) {
            if (aPlayer == this.player1) {
                hit = true;
            } else if (aPlayer == this.player2) {
                hit2 = true;
            }
        } else if (circleIntersect(this.bubble3, aPlayer)) {
            if (aPlayer == this.player1) {
                hit = true;
            } else if (aPlayer == this.player2) {
                hit2 = true;
            }
        } else if (circleIntersect(this.bubble4, aPlayer)) {
            if (aPlayer == this.player1) {
                hit = true;
            } else if (aPlayer == this.player2) {
                hit2 = true;
            }
        }
    }

    hidePlayer() {
        if (hit == true) {
            this.player1.x = 1000;
        } else if (hit2 == true) {
            this.player2.x = 1000;
        }
    
        if (hit == true && hit2 == false) {
            textAlign(CENTER);
            textSize(48);
            text("Player 2 Wins!", width / 2, height / 2);
        } else if (hit == false && hit2 == true) {
            textAlign(CENTER);
            textSize(48);
            text("Player 1 Wins!", width / 2, height / 2);
        } else if (hit == true && hit2 == true) {
            this.player1.x = 1000;
            this.player2.x = 1000;
            textAlign(CENTER);
            textSize(48);
            text("Press CTRL + R To Retry", width / 2, height / 2);
        }
    
    }
}

function collision(aPlayer) {
    if (circleIntersect(bubble1, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble2, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble3, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble4, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    }
}

