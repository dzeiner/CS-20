function initGlobals() {
    player1 = new JumpingPlayer(200, 300, 0, 65, 68, 87, 83);
    player2 = new JumpingPlayer(600, 300, 255, 37, 39, 38, 40);
    bubble1 = new Bubble(200, 400, 30, RED);
    bubble2 = new Bubble(500, 100, 20, BLUE);
    bubble3 = new Bubble(300, 500, 10, BROWN);
    bubble4 = new Bubble(100, 200, 25, GREY);
}

function moveObjects() {
    player1.move();
    player2.move();

    bubble1.move();
    bubble2.move();
    bubble3.move();
    bubble4.move();
}

function drawObjects() {
    player1.show();
    player2.show();

    bubble1.show();
    bubble2.show();
    bubble3.show();
    bubble4.show();
}

function collision(aPlayer) {
    if (circleIntersect(bubble1, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble2, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble3, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    } else if (circleIntersect(bubble4, aPlayer)) {
        if (aPlayer == player1) {
            hit = true;
        } else if (aPlayer == player2) {
            hit2 = true;
        }
    }
}

function hidePlayer() {
    if (hit == true) {
        player1.x = 1000;
    } else if (hit2 == true) {
        player2.x = 1000;
    }

    if (hit == true && hit2 == false) {
        textAlign(CENTER);
        textSize(48);
        text("Player 2 Wins!", width / 2, height / 2);
    } else if (hit == false && hit2 == true) {
        textAlign(CENTER);
        textSize(48);
        text("Player 1 Wins!", width / 2, height / 2);
    } else if (hit == true && hit2 == true) {
        player1.x = 1000;
        player2.x = 1000;
        textAlign(CENTER);
        textSize(48);
        text("Press CTRL + R To Retry", width / 2, height / 2);
    }

}
