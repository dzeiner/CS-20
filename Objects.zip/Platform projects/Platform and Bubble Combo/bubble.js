// CODE FOR A BUBBLE OBJECT
// Class - Factory or blueprint to build object
class Bubble {
	constructor(y) {
		//Properties (state)
		//Runs Once when Bubble object is created
		this.x = 400;
		this.y = y;
		this.r = random(1, 50);
	}

	// Methods (Behaviour)
	move() {
		// Move Bubble Randomly
		this.x += random(-1, 1);
		this.y += random(-1, 1);
	}

	show() {
		// Draw Bubble
		noFill();
		stroke(255, 180);
		strokeWeight(3);
		ellipse(this.x, this.y, 2 * this.r);
	}


}