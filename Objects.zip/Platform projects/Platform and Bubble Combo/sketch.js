// Declare Global Variables
let player, player2;
let bubble, bubble2, bubble3, bubble4;

// SETUP FUNCTION - Runs once at beginning of program
function setup() {
	createCanvas(800, 600);

	// Initialize Global Variables
    player = new JumpingPlayer(100, 300, 0, 65, 68, 87);
    player2 = new JumpingPlayer(700, 300, 255, 37, 39, 38);
    bubble = new Bubble(100);
    bubble2 = new Bubble(250);
    bubble3 = new Bubble(350);
    bubble4 = new Bubble(500);
}

// DRAW FUNCTION - Loops @ 60FPS by default
function draw() {
    // Logic
    player.move();
    player2.move();
    
    bubble.move();
    bubble2.move();
    bubble3.move();
    bubble4.move();

    // Draw
    background("red");
    player.show();
    player2.show();

    bubble.show();
    bubble2.show();
    bubble3.show();
    bubble4.show();

}

function keyPressed() {
    player.jump();
    player2.jump();
}
