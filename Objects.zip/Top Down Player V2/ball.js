function initBall() {
    ball = {
        x: 320,
        y: 180,
        r: 25,
        xSpeed: 5,
        ySpeed: 2,
        draw: function() {
            ellipse(ball.x, ball.y, ball.r*2, ball.r*2);
        },
        move: function() {
            ball.y += ball.ySpeed;
            ball.x += ball.xSpeed;
            if (ball.x > width - ball.r || ball.x < ball.r) {
                ball.xSpeed = -ball.xSpeed;
            }
            if (ball.y > height - ball.r || ball.y < ball.r) {
                ball.ySpeed = -ball.ySpeed;
            }
        }
    };
}