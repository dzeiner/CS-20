function initPlayer() {
	player1 = {
		x: width / 2, 
		y: height / 2,
		r: 15,
		speed: 5,
		col: 80,
		move: function() {
			 // LOGIC
		// Player 1 Movement
		if (keyIsDown(LEFT_ARROW) && player1.x > 15) {
			player1.x += -player1.speed;
		} else if (keyIsDown(RIGHT_ARROW) && player1.x < 785) {
			player1.x += player1.speed;
		} else if (keyIsDown(UP_ARROW) && player1.y > 15) {
			player1.y += -player1.speed;
		} else if (keyIsDown(DOWN_ARROW) && player1.y < 585) {
			player1.y += player1.speed;
		}
		},
		draw: function() {
			 // Draw Player 1
			fill(player1.col);
			noStroke();
			ellipse(player1.x, player1.y, 2 * player1.r);
			}
	};
}

function keyPressed() {
    //Teleport player when "T" is pressed
    if (keyCode == 84) {
    let teleX = random(15, 785);
    let teleY = random(15, 585);
    player1.x = teleX
    player1.y = teleY
    }
}