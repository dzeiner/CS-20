// TOP DOWN PLAYER

// Declare Global Variables
let player1, ball;

// SETUP FUNCTION - Runs once at beginning of program
function setup() {
	createCanvas(800, 600);
	
	// Initialize Global Variables
	initPlayer();
	initBall();
}

// DRAW FUNCTION - Loops @ 60FPS by default
function draw() {
	  player1.move();
	  ball.move();	
	// DRAW
	background(140, 197, 66);
	ball.draw();
	player1.draw();
}
