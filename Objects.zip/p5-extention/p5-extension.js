function square(x, y, s) {
    // Draw a square by setting it's x and y values along with a side length value
    rect(x, y, s, s);
}

function star(x, y, s) {
    // Draw a star by setting it's x and y values along with it's size
    // Top Of Star
    line(x, y, x + s, y + s * 2.25);
    line(x, y, x - s, y + s * 2.25);
    // Outwards Upper Star
    line(x + s, y + s * 2.25, x + s * 3, y + s * 2.25);
    line(x - s, y + s * 2.25, x - s * 3, y + s * 2.25);
    // Inwards Mid Star
    line(x + s * 3, y + s * 2.25, x + s * 1.5, y + s * 3.5);
    line(x - s * 3, y + s * 2.25, x - s * 1.5, y + s * 3.5);
    // Outwards Lower Star
    line(x + s * 1.5, y + s * 3.5, x + s * 2, y + s * 5.75);
    line(x - s * 1.5, y + s * 3.5, x - s * 2, y + s * 5.75);
    // Inner Lower Star
    line(x + s * 2, y + s * 5.75, x, y + s * 4.375);
    line(x - s * 2, y + s * 5.75, x, y + s * 4.375);
}

function octagon(x, y, s) {
   // Top Line
    line(x, y, x + s, y)
    // Top Right Line
    line(x + s, y, x + s * 1.707, y + s * 0.707)
    // Right Line
    line(x + s * 1.707, y + s * 0.707, x + s * 1.707, y + s * 1.707)
    // Bottom Right Line
    line(x + s * 1.707, y + s * 1.707, x + s, y + s * 2.414)
    // Bottom Line
    line(x + s, y + s * 2.414, x, y + s * 2.414)
    // Bottom Left Line
    line(x, y + s * 2.414, x - s * 0.707, y + s * 1.707)
    // Left Line
    line(x - s * 0.707, y + s * 1.707, x - s * 0.707, y + s * 0.707)
    // Top Left Line
    line(x - s * 0.707, y + s * 0.707, x, y)
}

function setup() {
    createCanvas(800, 800)
    
}

function draw() {
    let cred = random(1, 255)
    let cgreen = random(1, 255)
    let cblue = random(1, 255)
    stroke(cred, cgreen, cblue)
    strokeWeight(10)
    let fun = random(1,200)
    octagon(400, 200, fun);
    octagon(400, 200, 51)
}